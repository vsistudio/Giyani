import express from 'express';
import path from 'path';
import cors from 'cors';
import helmet from 'helmet';
import { createServer as createViteServer } from 'vite';
import verifyRoutes from './src/routes/verify';
import authRoutes from './src/routes/auth';
import chatRoutes from './src/routes/chat';
import { generalLimiter } from './src/middleware/rateLimiter';
import { errorHandler } from './src/middleware/errorHandler';
import { Logger } from './src/utils/logger';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Configure Helmet security headers with permissive CSP for CDNs used in index.html
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: [
            "'self'",
            "'unsafe-inline'",
            "'unsafe-eval'",
            "https://cdn.tailwindcss.com",
            "https://cdnjs.cloudflare.com",
            "https://cdn.jsdelivr.net",
            "https://www.gstatic.com"
          ],
          styleSrc: [
            "'self'",
            "'unsafe-inline'",
            "https://fonts.googleapis.com",
            "https://cdnjs.cloudflare.com"
          ],
          fontSrc: [
            "'self'",
            "https://fonts.gstatic.com",
            "https://cdnjs.cloudflare.com"
          ],
          imgSrc: ["'self'", "data:", "blob:", "https:"],
          connectSrc: ["'self'", "https:", "wss:"]
        }
      },
      crossOriginEmbedderPolicy: false
    })
  );

  app.use(cors());
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));
  app.use(generalLimiter);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Gyani Sahur AI Server',
      timestamp: new Date().toISOString()
    });
  });

  // Mount API routes
  app.use('/api', verifyRoutes);
  app.use('/api', authRoutes);
  app.use('/api', chatRoutes);

  // Error handling middleware for API routes
  app.use('/api', errorHandler);

  // Vite middleware for development vs static production serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    Logger.info(`Gyani Sahur AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
