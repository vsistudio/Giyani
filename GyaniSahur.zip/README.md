# Gyani Sahur AI | Premium Hyper Edition by VsiStudio

Gyani Sahur AI is a private enterprise intelligence platform developed by **VsiStudio** (CEO: Vivan Sahu). It features two dedicated operational AI modes: **Gyani Hyper** (powered by Groq Llama 3.3 for lightning-fast reasoning and code generation) and **Gyani NightMare** (dark, blunt, highly analytical unfiltered intelligence protocol).

---

## 🌟 Key Features

- **Dual AI Modes**:
  - **Hyper Mode**: High-throughput intelligence using Groq Llama 3.3 (`llama-3.3-70b-versatile`) with server-side Gemini fallback.
  - **Nightmare Mode**: Direct, unfiltered, brutally honest analytical intelligence.
- **Enterprise Security**:
  - Password gate access protection (`Better LuckNextTime`).
  - Google Firebase & Guest Authentication.
  - Express Helmet security headers, CORS protection, rate limiting, and input sanitization.
  - Complete client-side isolation — API keys (`GROQ_API_KEY`, `MANUS_API_KEY`, `GEMINI_API_KEY`) are stored server-side.
- **Rich Interactive UI**:
  - Code syntax highlighting with one-click copy terminal header.
  - Markdown, GFM tables, blockquotes, and custom rendering.
  - Multimodal media attachment support.
  - Speech recognition dictation & text-to-speech voice identity customization.
  - Workspace management with persistent storage.

---

## 🚀 Getting Started

### Prerequisites

- Node.js (v18+)
- npm

### Installation

1. Clone or download the repository.
2. Install dependencies:
   ```bash
   npm install
   ```

### Environment Variables Setup

Copy `.env.example` to `.env` and fill in your API credentials:

```bash
cp .env.example .env
```

Set the variables in `.env`:

```env
GROQ_API_KEY=your_groq_api_key_here
MANUS_API_KEY=your_manus_api_key_here
GEMINI_API_KEY=your_gemini_api_key_here
ACCESS_PASSWORD=JaiSiyaram[(OnlyVsi)]
JWT_SECRET=your_jwt_secret_key
SESSION_SECRET=your_session_secret_key
```

---

## 💻 Running the Application

### Development Mode

Run the Express backend with live Vite middleware on port 3000:

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000) in your browser.

### Production Build & Deployment

1. Compile client assets and bundle the server into `dist/server.cjs`:
   ```bash
   npm run build
   ```

2. Start the production server:
   ```bash
   npm run start
   ```

---

## 🛡️ API Key & Security Compliance

- **No Secrets in Client Code**: All AI model calls are proxied through `/api/chat`.
- **Password Protection**: Access gate verified via `/api/verify`.
- **Rate Limiting**: Protects `/api/chat` (30 req/min) and auth endpoints (10 req/15 min).

---

## 🏢 Creator Notice
Gyani Sahur AI is created by **Vivan Sahu**, CEO of **VsiStudio** (Vivan & Sachar International Studio).
