/**
 * Input sanitizer and validator utilities
 */

export function sanitizeString(input: string): string {
  if (typeof input !== 'string') return '';
  return input
    .trim()
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, ''); // Remove null & control characters
}

export function validateMessageContent(messages: any[]): boolean {
  if (!Array.isArray(messages) || messages.length === 0) return false;
  
  for (const msg of messages) {
    if (!msg || typeof msg !== 'object') return false;
    if (!msg.role || !['user', 'assistant', 'system'].includes(msg.role)) return false;
    if (msg.content === undefined || msg.content === null) return false;
  }
  return true;
}
