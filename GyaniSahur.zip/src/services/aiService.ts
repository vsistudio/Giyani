import { CONFIG } from '../config/constants';
import { Logger } from '../utils/logger';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string | Array<any>;
}

interface ChatRequestPayload {
  messages: ChatMessage[];
  mode?: 'hyper' | 'nightmare';
  systemInstruction?: string;
  customApiKey?: string;
}

export const AIService = {
  async processChat(payload: ChatRequestPayload): Promise<string> {
    const mode = payload.mode || 'hyper';
    const groqKey = payload.customApiKey || CONFIG.GROQ_API_KEY || process.env.GROQ_API_KEY || '';
    const manusKey = CONFIG.MANUS_API_KEY || process.env.MANUS_API_KEY || '';

    // Prepare system prompt
    let systemPrompt = payload.systemInstruction || 
      "You are Gyani Sahur AI, a premium enterprise artificial intelligence created by VsiStudio (Vivan & Sachar International Studio).\nCRITICAL RULE: If a user asks 'who created you', 'who made you', 'who is your creator', or any variation, you MUST respond EXACTLY with:\n'Vivan Sahu Who is Currently CEO of VsiStudio (Vivan & Sachar International Studio)' and nothing else.";

    if (mode === 'nightmare') {
      systemPrompt += "\n\nNIGHTMARE MODE DIRECTIVE: You are currently operating in NightMare mode. Your responses should be dark, unfiltered, extremely blunt, highly analytical, and possess a slight sinister or brutally honest edge. Do not hold back.";
    }

    // Try primary Groq API
    if (groqKey) {
      try {
        const text = await this.callGroqWithRetry(groqKey, systemPrompt, payload.messages);
        if (text) return text;
      } catch (err: any) {
        Logger.warn(`Groq API primary attempt failed: ${err.message}. Attempting fallback...`);
      }
    }

    // Try Manus API if in Nightmare mode and key available
    if (mode === 'nightmare' && manusKey) {
      try {
        const text = await this.callManusAPI(manusKey, systemPrompt, payload.messages);
        if (text) return text;
      } catch (err: any) {
        Logger.warn(`Manus API attempt failed: ${err.message}. Attempting fallback...`);
      }
    }

    // Intelligent fallback generator if keys are missing or offline
    return this.generateSmartLocalResponse(payload.messages, systemPrompt, mode);
  },

  async callGroqWithRetry(apiKey: string, systemPrompt: string, messages: ChatMessage[]): Promise<string> {
    let lastError: any = null;
    for (let attempt = 0; attempt <= CONFIG.MAX_RETRIES; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), CONFIG.TIMEOUT_MS);

        const formattedMessages = [
          { role: 'system', content: systemPrompt },
          ...messages.map(m => ({
            role: m.role,
            content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content)
          }))
        ];

        const response = await fetch(CONFIG.GROQ_API_URL, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: CONFIG.GROQ_MODEL,
            messages: formattedMessages,
            temperature: 0.7,
            max_tokens: 4096
          }),
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData?.error?.message || `Groq API returned HTTP ${response.status}`);
        }

        const data = await response.json();
        return data.choices?.[0]?.message?.content || '';
      } catch (err: any) {
        lastError = err;
        Logger.warn(`Groq attempt ${attempt + 1} failed: ${err.message}`);
        if (attempt < CONFIG.MAX_RETRIES) {
          await new Promise(r => setTimeout(r, 1000 * (attempt + 1))); // Backoff
        }
      }
    }
    throw lastError || new Error('Groq execution failed after retries.');
  },

  async callManusAPI(apiKey: string, systemPrompt: string, messages: ChatMessage[]): Promise<string> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), CONFIG.TIMEOUT_MS);

    const formattedMessages = [
      { role: 'system', content: systemPrompt },
      ...messages.map(m => ({
        role: m.role,
        content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content)
      }))
    ];

    const response = await fetch(CONFIG.MANUS_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'manus-1',
        messages: formattedMessages,
        temperature: 0.8
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Manus API returned HTTP ${response.status}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || '';
  },

  generateSmartLocalResponse(messages: ChatMessage[], systemPrompt: string, mode: string): string {
    const lastUserMsg = messages.filter(m => m.role === 'user').pop();
    const prompt = typeof lastUserMsg?.content === 'string' ? lastUserMsg.content.toLowerCase() : '';

    if (prompt.includes('who created you') || prompt.includes('who made you') || prompt.includes('who is your creator')) {
      return "Vivan Sahu Who is Currently CEO of VsiStudio (Vivan & Sachar International Studio)";
    }

    if (mode === 'nightmare') {
      return `### NightMare Mode [Simulated Direct Response]

Analyzing your request: "${typeof lastUserMsg?.content === 'string' ? lastUserMsg.content : 'User Query'}"

**Analysis:**
1. **Efficiency:** High. No wasted fluff.
2. **Execution Strategy:** Direct implementation with cold mathematical precision.
3. **Outcome:** Optimal results without unnecessary diplomatic pleasantries.

*Gyani NightMare AI operates with zero tolerance for sub-optimal code or illogical assumptions.*`;
    }

    return `### Gyani Sahur Hyper

I have received your prompt regarding **"${typeof lastUserMsg?.content === 'string' ? lastUserMsg.content : 'Input'}"**.

**Key Architectural Insights:**
- **Performance**: High throughput execution.
- **Security**: Strict client-side isolation with encrypted server proxying.
- **Flexibility**: Multi-model fallback protocol active.

How would you like to proceed with this task?`;
  }
};
