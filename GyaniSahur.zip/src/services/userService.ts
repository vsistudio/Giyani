import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { CONFIG } from '../config/constants';

export interface User {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  createdAt: number;
}

// In-memory user store for non-Firebase users + token helper
const usersDb: Map<string, User> = new Map();

export const UserService = {
  async register(email: string, name: string, passwordPlain: string): Promise<{ user: Omit<User, 'passwordHash'>; token: string }> {
    const existing = Array.from(usersDb.values()).find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      throw new Error('User with this email already exists.');
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(passwordPlain, salt);

    const id = 'usr_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    const newUser: User = {
      id,
      email,
      name,
      passwordHash,
      createdAt: Date.now()
    };

    usersDb.set(id, newUser);

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, name: newUser.name },
      CONFIG.JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = newUser;
    return { user: safeUser, token };
  },

  async login(email: string, passwordPlain: string): Promise<{ user: Omit<User, 'passwordHash'>; token: string }> {
    const user = Array.from(usersDb.values()).find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      throw new Error('Invalid email or password.');
    }

    const isMatch = await bcrypt.compare(passwordPlain, user.passwordHash);
    if (!isMatch) {
      throw new Error('Invalid email or password.');
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      CONFIG.JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = user;
    return { user: safeUser, token };
  },

  getUserById(id: string): Omit<User, 'passwordHash'> | null {
    const user = usersDb.get(id);
    if (!user) return null;
    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
  }
};
