import dotenv from 'dotenv';
dotenv.config();

export const CONFIG = {
  PORT: process.env.PORT || 3000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  DEFAULT_ACCESS_PASSWORD: process.env.ACCESS_PASSWORD || 'Better LuckNextTime',
  JWT_SECRET: process.env.JWT_SECRET || 'gyani_sahur_vsi_studio_jwt_secret_key_2026',
  GROQ_API_KEY: process.env.GROQ_API_KEY || '',
  MANUS_API_KEY: process.env.MANUS_API_KEY || '',
  GROQ_MODEL: 'llama-3.3-70b-versatile',
  GROQ_API_URL: 'https://api.groq.com/openai/v1/chat/completions',
  MANUS_API_URL: 'https://api.manus.im/v1/chat/completions', // Standard proxy fallback
  TIMEOUT_MS: 30000, // 30s timeout
  MAX_RETRIES: 2
};
