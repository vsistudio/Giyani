import { Request, Response, NextFunction } from 'express';
import { Logger } from '../utils/logger';

export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  Logger.error('Unhandled server error:', err.message || err);
  
  const statusCode = err.status || err.statusCode || 500;
  const message = process.env.NODE_ENV === 'production' 
    ? 'An unexpected server error occurred. Please try again.'
    : (err.message || 'Internal Server Error');

  res.status(statusCode).json({
    error: message,
    status: 'error'
  });
}
