import { Router, Response } from 'express';
import { AIService } from '../services/aiService';
import { apiLimiter } from '../middleware/rateLimiter';
import { validateMessageContent } from '../utils/sanitizer';
import { AuthenticatedRequest } from '../middleware/auth';
import { Logger } from '../utils/logger';

const router = Router();

router.post('/chat', apiLimiter, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { messages, mode, systemInstruction, customApiKey } = req.body;

    if (!validateMessageContent(messages)) {
      return res.status(400).json({ error: 'Invalid message array payload' });
    }

    const aiResponseContent = await AIService.processChat({
      messages,
      mode,
      systemInstruction,
      customApiKey
    });

    return res.json({
      id: 'chatcmpl_' + Date.now().toString(36),
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      choices: [
        {
          index: 0,
          message: {
            role: 'assistant',
            content: aiResponseContent
          },
          finish_reason: 'stop'
        }
      ]
    });
  } catch (error: any) {
    Logger.error('Error in /api/chat route:', error);
    return res.status(500).json({ error: error.message || 'Error executing AI request' });
  }
});

export default router;
