import { Router, Request, Response } from 'express';
import { CONFIG } from '../config/constants';
import { authLimiter } from '../middleware/rateLimiter';
import { Logger } from '../utils/logger';

const router = Router();

router.post('/verify', authLimiter, (req: Request, res: Response) => {
  try {
    const { password } = req.body;
    
    if (!password) {
      return res.status(400).json({ success: false, message: 'Password is required' });
    }

    const expectedPassword = process.env.ACCESS_PASSWORD || CONFIG.DEFAULT_ACCESS_PASSWORD;

    if (password === expectedPassword) {
      Logger.info('Password verification successful');
      return res.json({ success: true, message: 'Access granted' });
    } else {
      Logger.warn('Password verification failed');
      return res.status(401).json({ success: false, message: 'Incorrect password' });
    }
  } catch (error: any) {
    Logger.error('Error during password verification:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

export default router;
