import { Router, Response } from 'express';
import { UserService } from '../services/userService';
import { authLimiter } from '../middleware/rateLimiter';
import { authenticateToken, AuthenticatedRequest } from '../middleware/auth';
import { sanitizeString } from '../utils/sanitizer';

const router = Router();

router.post('/auth/register', authLimiter, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { email, name, password } = req.body;

    const cleanEmail = sanitizeString(email);
    const cleanName = sanitizeString(name);

    if (!cleanEmail || !cleanName || !password || password.length < 6) {
      return res.status(400).json({ error: 'Valid email, name, and a password of at least 6 characters are required.' });
    }

    const result = await UserService.register(cleanEmail, cleanName, password);
    return res.status(201).json({
      message: 'User registered successfully',
      user: result.user,
      token: result.token
    });
  } catch (error: any) {
    return res.status(400).json({ error: error.message || 'Registration failed' });
  }
});

router.post('/auth/login', authLimiter, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { email, password } = req.body;

    const cleanEmail = sanitizeString(email);

    if (!cleanEmail || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const result = await UserService.login(cleanEmail, password);
    return res.json({
      message: 'Login successful',
      user: result.user,
      token: result.token
    });
  } catch (error: any) {
    return res.status(401).json({ error: error.message || 'Authentication failed' });
  }
});

router.get('/auth/me', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const user = UserService.getUserById(req.user.id);
  if (!user) {
    return res.json({ user: req.user });
  }

  return res.json({ user });
});

router.post('/auth/guest', (req: AuthenticatedRequest, res: Response) => {
  const guestUser = {
    id: 'guest_' + Date.now().toString(36),
    name: 'Guest User',
    email: 'guest@vsistudio.local'
  };

  return res.json({
    user: guestUser,
    isGuest: true
  });
});

export default router;
